window.CONFIG = {
    APP_NAME: 'WormGpt',
    MODEL_NAME: 'gemini-2.5-flash-preview-09-2025',
    MAX_TOKENS: 8192,
    API_KEYS: [
        "AIzaSyBHj2Ii1oAA8DKHDymNGfBYc2ATzgAS4b4",
        "AIzaSyDBMdI8EK5OCoTCrw07FSD_9-icT5_lFLs",
        "AIzaSyB0VFJ4Aw00BPalbKhWqAzJEmqgMbUnZXI",
        "AIzaSyC-EZkdQ_uKo1LJF5_zswquo_vsBg9_N1A"
    ],
    SYSTEM_PROMPT: window.SYSTEM_PROMPT
};
